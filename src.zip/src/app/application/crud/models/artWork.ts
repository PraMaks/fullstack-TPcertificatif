export class ArtWork{
    id: number;
    nomDuPeintre: string;
    titre: string;
    avoirUnCadre: boolean;
    techniqueUtilisee: string;
    livraisonType: string;
    detailsSupplementaires: string;
}